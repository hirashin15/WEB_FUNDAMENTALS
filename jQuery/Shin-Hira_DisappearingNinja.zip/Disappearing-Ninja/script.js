$(document).ready(function(){

  $(".ninja1").click(function(){
    $(".ninja1").css("display", "none")
  })
  $(".ninja2").click(function(){
    $(".ninja2").css("display", "none")
  })
  $(".ninja3").click(function(){
    $(".ninja3").css("display", "none")
  })
  $(".ninja4").click(function(){
    $(".ninja4").css("display", "none")
  })
  $(".ninja5").click(function(){
    $(".ninja5").css("display", "none")
  })
  $(".ninja6").click(function(){
    $(".ninja6").css("display", "none")
  })
  $(".ninja7").click(function(){
    $(".ninja7").css("display", "none")
  })
  $(".ninja8").click(function(){
    $(".ninja8").css("display", "none")
  })

  $("button").click(function(){
    $(".ninja1:hidden").show()
    $(".ninja2:hidden").show()
    $(".ninja3:hidden").show()
    $(".ninja4:hidden").show()
    $(".ninja5:hidden").show()
    $(".ninja6:hidden").show()
    $(".ninja7:hidden").show()
    $(".ninja8:hidden").show()
  })

})